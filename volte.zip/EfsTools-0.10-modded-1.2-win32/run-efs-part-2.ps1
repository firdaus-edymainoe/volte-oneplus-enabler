.\EfsTools.exe uploadDirectory -i mcfg_sw.mbn -o / -v

.\EfsTools.exe uploadDirectory -i mcfg_sw.mbn -o / -s 1